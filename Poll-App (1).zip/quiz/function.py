def handle_uploaded_file(f,name):  
    with open('quiz/static/upload/'+name+" "+f.name, 'wb+') as destination:  
        for chunk in f.chunks():  
            destination.write(chunk) 